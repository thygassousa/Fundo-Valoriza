package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.services.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CursoController {

    @Autowired
    private CursoService cursoService;

    @GetMapping("/cursos")
    public String listarCursos(Model model) {
        model.addAttribute("cursos", cursoService.listarTodosCursos());
        return "cursos"; // Template cursos.html
    }
}
