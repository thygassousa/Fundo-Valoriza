package com.cursosfinanceiros.fundovaloriza.config;

import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfig {

    private final UsuarioService usuarioService;
    private final PasswordEncoder passwordEncoder;  // Injetando o PasswordEncoder

    // Injeção de dependência via construtor
    public SecurityConfig(UsuarioService usuarioService, PasswordEncoder passwordEncoder) {
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeRequests(authorize -> authorize
                        .requestMatchers("/", "/auth/**", "/css/**", "/js/**", "/imagens/**", "/fonts/**", "/webjars/**")
                        .permitAll()  // Permite o acesso livre a essas páginas
                        .anyRequest().authenticated()  // Requer autenticação para outras páginas
                )
                .formLogin(form -> form
                        .loginPage("/auth/login")  // Página de login personalizada
                        .defaultSuccessUrl("/", true)  // Redireciona para a home após login
                        .permitAll()  // Permite o acesso à página de login
                )
                .oauth2Login(oauth2 -> oauth2
                        .loginPage("/auth/login")  // Página de login personalizada para OAuth2 (Google)
                        .defaultSuccessUrl("/", true)  // Redireciona para a home após login via OAuth2
                        .failureUrl("/auth/login?error=true")  // Caso ocorra erro no login
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")  // URL de logout
                        .logoutSuccessUrl("/")  // Redireciona para a home após logout
                        .invalidateHttpSession(true)  // Invalida a sessão ao fazer logout
                        .permitAll()  // Permite o acesso ao logout
                )
                .sessionManagement(session -> session
                        .invalidSessionUrl("/auth/login")  // Redireciona para login se a sessão for inválida
                        .maximumSessions(1)  // Limita a 1 sessão por usuário
                        .maxSessionsPreventsLogin(true)  // Impede login múltiplo
                )
                .csrf(csrf -> csrf
                        .disable()  // Desabilita a proteção CSRF corretamente
                );

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.userDetailsService(usuarioService).passwordEncoder(passwordEncoder);  // Usando PasswordEncoder
        return authenticationManagerBuilder.build();
    }
}
