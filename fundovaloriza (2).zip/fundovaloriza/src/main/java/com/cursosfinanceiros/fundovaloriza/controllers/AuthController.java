package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/auth/login")
    public String exibirLogin() {
        return "login"; // Template login.html
    }

    @GetMapping("/auth/cadastro")
    public String exibirCadastro() {
        return "cadastro"; // Template cadastro.html
    }

    @PostMapping("/auth/cadastro")
    public String processarCadastro(@Validated Usuario usuario, BindingResult result, Model model) {
        if (result.hasErrors()) {
            // Se houver erros de validação, retorna para a página de cadastro
            return "cadastro";
        }

        try {
            // Verifica se o e-mail já está cadastrado
            if (usuarioService.verificarEmailExistente(usuario.getEmail())) {
                model.addAttribute("erro", "E-mail já cadastrado.");
                return "cadastro"; // Retorna para o formulário com a mensagem de erro
            }

            // Tenta cadastrar o usuário
            usuarioService.cadastrarUsuario(usuario);
            return "redirect:/auth/login";  // Redireciona para o login após o cadastro
        } catch (RuntimeException e) {
            // Se ocorrer um erro, exibe a mensagem
            model.addAttribute("erro", e.getMessage());
            return "cadastro";  // Retorna para a página de cadastro com erro
        }
    }
}
