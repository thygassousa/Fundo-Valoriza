package com.cursosfinanceiros.fundovaloriza.config;

import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    private final UsuarioService usuarioService;

    // Injeção de dependência via construtor
    public SecurityConfig(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeRequests(authorize -> authorize
                        .requestMatchers("/", "/auth/**", "/css/**", "/js/**", "/imagens/**", "/fonts/**", "/webjars/**")
                        .permitAll()
                        .anyRequest().authenticated()  // Requer autenticação para outras páginas
                )
                .formLogin(form -> form
                        .loginPage("/auth/login")  // Página de login personalizada
                        .defaultSuccessUrl("/", true)  // Redireciona para a home após login
                        .permitAll()  // Permite acesso à página de login
                )
                .oauth2Login(oauth2 -> oauth2
                        .loginPage("/auth/login")  // Página de login personalizada para OAuth2 (Google)
                        .defaultSuccessUrl("/", true)  // Redireciona para a home após login via OAuth2
                        .failureUrl("/auth/login?error=true")  // Caso ocorra erro no login
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")  // URL de logout
                        .logoutSuccessUrl("/")  // Redireciona para a home após logout
                        .invalidateHttpSession(true)  // Invalida a sessão ao fazer logout
                        .permitAll()  // Permite acesso ao logout
                )
                .sessionManagement(session -> session
                        .invalidSessionUrl("/auth/login")  // Redireciona para login se a sessão for inválida
                        .maximumSessions(1)  // Limita a 1 sessão por usuário
                        .maxSessionsPreventsLogin(true)  // Impede login múltiplo
                );

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        // Configura o AuthenticationManager com o UserDetailsService
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.userDetailsService(usuarioService);
        return authenticationManagerBuilder.build();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return usuarioService;
    }
}
