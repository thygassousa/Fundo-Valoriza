package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Método para cadastrar o usuário
    public Usuario cadastrarUsuario(Usuario usuario) {
        // Verifica se o e-mail já está cadastrado
        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioExistente.isPresent()) {
            throw new EmailAlreadyExistsException("E-mail já cadastrado.");
        }
        // Sem criptografia de senha, a senha será salva como está
        return usuarioRepository.save(usuario);
    }

    // Método para buscar usuário por e-mail
    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    // Método para validar a senha
    public boolean validarSenha(String senhaOriginal, String senhaCriptografada) {
        return senhaOriginal.equals(senhaCriptografada);
    }

    // Método para verificar se o e-mail já existe
    public boolean verificarEmailExistente(String email) {
        // Verifica se o usuário com o e-mail já existe no banco de dados
        return usuarioRepository.findByEmail(email).isPresent();
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Busca o usuário pelo e-mail
        Usuario usuario = usuarioRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));

        return buildUser(usuario);
    }

    private UserDetails buildUser(Usuario usuario) {
        // Construção do objeto UserDetails
        User.UserBuilder builder = User.withUsername(usuario.getEmail())
                .authorities("ROLE_USER");

        if (usuario.isAutenticadoComGoogle()) {
            // Se autenticado com Google, a senha é vazia
            builder.password("");
        } else {
            // Caso contrário, utiliza a senha sem criptografia
            builder.password(usuario.getSenha());
        }

        return builder.build();
    }
}

// Exceção personalizada para e-mail já existente
class EmailAlreadyExistsException extends RuntimeException {
    public EmailAlreadyExistsException(String message) {
        super(message);
    }
}
