const express = require('express');
const pool = require('../models/db');
const jwt = require('jsonwebtoken');  // Importar o jwt aqui
const verificarToken = require('../middleware/verificarToken');
const router = express.Router();

// Endpoint para listar cursos com filtro por categoria
router.get('/listar', async (req, res) => {
    const categoria = req.query.categoria ? req.query.categoria.replace(/\+/g, ' ') : 'todos'; // Normaliza a categoria
    let query = 'SELECT * FROM cursos';
    const params = [];

    if (categoria !== 'todos') {
        query += ' WHERE category = ?';
        params.push(categoria);
    }

    try {
        const [rows] = await pool.promise().query(query, params);
        res.status(200).json(rows);
    } catch (err) {
        console.error('Erro ao listar cursos:', err);
        res.status(500).json({ message: 'Erro ao listar cursos' });
    }
});


// Rota para obter os detalhes do curso
router.get('/detalhes', (req, res) => {  // Remover verificarToken para teste
    const { id } = req.query;

    if (!id) {
        return res.status(400).json({ message: 'ID do curso não fornecido.' });
    }

    const query = 'SELECT * FROM cursos WHERE id = ?';
    pool.query(query, [id], (err, result) => {
        if (err) {
            console.error('Erro ao buscar curso:', err);
            return res.status(500).json({ message: 'Erro ao buscar curso.' });
        }

        if (result.length === 0) {
            return res.status(404).json({ message: 'Curso não encontrado.' });
        }

        const curso = result[0];
        console.log('Curso encontrado:', curso);
        res.status(200).json({
            id: curso.id,
            title: curso.title,
            description: curso.description,
            category: curso.category,
            creation_date: curso.creation_date,
            video_url: curso.video_url
        });
    });
});


router.post('/inscrever', verificarToken, (req, res) => {
    const usuarioId = req.user.id;  // O id do usuário vindo do JWT ou da sessão
    const usuarioNome = req.user.nome;  // Supondo que o nome do usuário esteja armazenado no JWT
    const { curso_id } = req.body;

    if (!usuarioId) {
        return res.status(400).send('Usuário não está logado.');
    }

    const checkCourseQuery = 'SELECT * FROM cursos WHERE id = ?';
    pool.query(checkCourseQuery, [curso_id], (err, results) => {
        if (err) {
            console.error('Erro ao verificar curso:', err);
            return res.status(500).send('Erro ao verificar curso.');
        }

        if (results.length === 0) {
            return res.status(404).send('Curso não encontrado.');
        }

        // Agora, insira o nome do usuário na consulta
        const insertQuery = 'INSERT INTO inscricoes (usuario_id, usuario_nome, curso_id, data_inscricao) VALUES (?, ?, ?, NOW())';
        pool.query(insertQuery, [usuarioId, usuarioNome, curso_id], (err, result) => {
            if (err) {
                console.error('Erro ao inscrever no curso:', err);
                return res.status(500).send('Erro ao inscrever no curso.');
            }
            res.status(201).send('Inscrição realizada com sucesso!');
        });
        
    });
});



// Rota para verificar se o usuário está inscrito no curso
router.get('/verificar-inscricao', verificarToken, (req, res) => {
    const { curso_id } = req.query;
    const usuario_id = req.user.id; // Agora o id do usuário estará disponível em req.user

    const query = 'SELECT COUNT(*) AS count FROM inscricoes WHERE usuario_id = ? AND curso_id = ?';
    pool.query(query, [usuario_id, curso_id], (err, results) => {
        if (err) {
            console.error('Erro ao verificar inscrição:', err);
            return res.status(500).json({ message: 'Erro ao verificar inscrição.' });
        }
        res.json({ inscrito: results[0].count > 0 });
    });
});



module.exports = router;
