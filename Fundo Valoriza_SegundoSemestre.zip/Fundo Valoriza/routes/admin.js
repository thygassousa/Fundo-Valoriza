const express = require('express');
const pool = require('../models/db');
const router = express.Router();

// Middleware para parsear o corpo da requisição como JSON
router.use(express.json());

// Listar todos os cursos
router.get('/cursos', (req, res) => {
    pool.query('SELECT * FROM cursos', (err, results) => {
        if (err) {
            console.error('Erro ao buscar cursos:', err);
            return res.status(500).send('Erro ao buscar cursos.');
        }
        res.json(results);
    });
});

router.post('/cursos', (req, res) => {
    const { title, description, category, video_url } = req.body;

    const checkQuery = 'SELECT COUNT(*) AS count FROM cursos WHERE title = ?';
    const insertQuery = 'INSERT INTO cursos (title, description, category, video_url, creation_date) VALUES (?, ?, ?, ?, NOW())';

    pool.query(checkQuery, [title], (err, results) => {
        if (err) {
            console.error('Erro ao verificar duplicidade:', err);
            return res.status(500).send('Erro ao verificar duplicidade.');
        }

        if (results[0].count > 0) {
            return res.status(409).json({ message: 'Curso com este título já existe. Escolha outro título.' });
        }

        pool.query(insertQuery, [title, description, category, video_url], (err, result) => {
            if (err) {
                console.error('Erro ao adicionar curso:', err);
                return res.status(500).send('Erro ao adicionar curso.');
            }
            res.status(201).json({
                id: result.insertId,
                title,
                description,
                category,
                video_url,
                creation_date: new Date().toISOString(),
                message: 'Curso adicionado com sucesso!'
            });
        });
    });
});




// Editar um curso
router.put('/cursos/:id', (req, res) => {
    const { id } = req.params;
    const { title, description, category, video_url } = req.body;
    const query = 'UPDATE cursos SET title = ?, description = ?, category = ?, video_url = ? WHERE id = ?';

    pool.query(query, [title, description, category, video_url, id], (err, result) => {
        if (err) {
            console.error('Erro ao atualizar curso:', err);
            return res.status(500).send('Erro ao atualizar curso.');
        }
        res.send({ message: 'Curso atualizado com sucesso!' });
    });
});


// Excluir um curso
router.delete('/cursos/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM cursos WHERE id = ?';

    pool.query(query, [id], (err, result) => {
        if (err) {
            console.error('Erro ao excluir curso:', err);
            return res.status(500).send('Erro ao excluir curso.');
        }
        res.send({ message: 'Curso excluído com sucesso!' });
    });
});
module.exports = router;
