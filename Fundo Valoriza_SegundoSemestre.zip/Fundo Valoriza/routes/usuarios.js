const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../models/db'); // Certifique-se de que 'db.js' está exportando o 'pool' corretamente
const router = express.Router();
const jwt = require('jsonwebtoken');

router.post('/cadastro', async (req, res) => {
  const { nome, sobrenome, email, telefone, dataNascimento, senha } = req.body;

  try {
    // Verificar se o e-mail já está em uso
    const [results] = await pool.promise().query('SELECT * FROM usuarios WHERE email = ?', [email]);

    if (results.length > 0) {
      return res.status(400).json({ message: 'E-mail já cadastrado.' });
    }

    // Criptografar a senha
    const hashedPassword = await bcrypt.hash(senha, 10);

    // Inserir o usuário no banco de dados
    const query = 'INSERT INTO usuarios (nome, sobrenome, email, telefone, data_nascimento, senha) VALUES (?, ?, ?, ?, ?, ?)';
    const [insertResult] = await pool.promise().query(query, [nome, sobrenome, email, telefone, dataNascimento, hashedPassword]);

    if (insertResult.affectedRows > 0) {
      return res.status(201).json({ message: 'Usuário cadastrado com sucesso!' });
    } else {
      return res.status(500).json({ message: 'Falha ao cadastrar usuário. Tente novamente.' });
    }
  } catch (err) {
    console.error('Erro ao cadastrar usuário:', err);
    return res.status(500).json({ message: 'Erro interno do servidor. Tente novamente mais tarde.' });
  }
});


// Rota de Login
router.post('/login', async (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
      return res.status(400).json({ message: 'Email e senha são obrigatórios.' });
  }

  try {
      pool.query('SELECT * FROM usuarios WHERE email = ?', [email], async (err, rows) => {
          if (err) {
              console.error('Erro na consulta ao banco:', err);
              return res.status(500).json({ message: 'Erro no servidor.' });
          }

          if (rows.length === 0) {
              return res.status(401).json({ message: 'Usuário não encontrado.' });
          }

          const usuario = rows[0];
          const senhaValida = await bcrypt.compare(senha, usuario.senha);

          if (!senhaValida) {
              return res.status(401).json({ message: 'Senha incorreta.' });
          }

          // Gerar token JWT
          const token = jwt.sign(
              { id: usuario.id, nome: usuario.nome, email: usuario.email, telefone: usuario.telefone, data_nascimento: usuario.data_nascimento },
              'secreta-chave',
              { expiresIn: '1h' }
          );
      
          res.status(200).json({
              message: 'Login realizado com sucesso!',
              token: token // Retorna o token gerado
          });
      });
  } catch (error) {
      console.error('Erro no login:', error);
      res.status(500).json({ message: 'Erro no servidor.' });
  }
});






router.get('/verificar', (req, res) => {
    const token = req.headers['authorization'];
    if (!token) {
        return res.status(401).json({ message: 'Token não fornecido' });
    }

    jwt.verify(token, 'secreta-chave', (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Token inválido' });
        }
        res.status(200).json({ message: 'Usuário autenticado', usuario: decoded });
    });
});


router.get('/perfil', async (req, res) => {
  const token = req.headers['authorization'];

  if (!token) {
      return res.status(401).json({ message: 'Token não fornecido' });
  }

  try {
      // Decodifica o token JWT para obter o ID do usuário
      const decoded = jwt.verify(token, 'secreta-chave');
      const usuarioId = decoded.id;

      // Consulta para buscar os dados do usuário
      const [usuarioResult] = await pool.promise().query(
          'SELECT nome, email, telefone, data_nascimento FROM usuarios WHERE id = ?',
          [usuarioId]
      );

      if (usuarioResult.length === 0) {
          return res.status(404).json({ message: 'Usuário não encontrado.' });
      }

      const usuario = usuarioResult[0];

      const [cursosResult] = await pool.promise().query(
        `SELECT c.id, c.title AS titulo
         FROM inscricoes i
         INNER JOIN cursos c ON i.curso_id = c.id
         WHERE i.usuario_id = ?`,
        [usuarioId]
    );
    
      res.status(200).json({
          usuario,
          cursos: cursosResult // Retorna os cursos inscritos
      });
  } catch (error) {
      console.error('Erro ao carregar perfil:', error);
      res.status(500).json({ message: 'Erro interno do servidor.' });
  }
});




module.exports = router;
