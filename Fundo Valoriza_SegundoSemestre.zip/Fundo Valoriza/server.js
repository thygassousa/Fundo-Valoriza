const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken'); // Adicionando a importação do jwt
const usuariosRouter = require('./routes/usuarios'); // Roteador de usuários


// Configuração do banco de dados MySQL usando Pool de Conexões
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'yagsKilobat@20',
  database: 'fundo_valoriza',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});



// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const adminRouter = require('./routes/admin');
app.use('/api/admin', adminRouter);


const cursosRouter = require('./routes/cursos');
app.use('/api/cursos', cursosRouter);


// Usar o roteador de usuários
app.use('/api/usuarios', usuariosRouter);

// Rota protegida de exemplo
app.get('/api/usuarios/perfil', (req, res) => {
  const token = req.headers['authorization'];

  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }

  jwt.verify(token, 'secreta-chave', (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido' });
    }

    res.json({ message: 'Perfil acessado com sucesso', usuario: decoded });
  });
});


// Rota para retornar os detalhes de um curso
app.get('/api/cursos/detalhes', async (req, res) => {
  const cursoId = req.query.id;

  if (!cursoId) {
    return res.status(400).json({ message: 'ID do curso não fornecido' });
  }

  try {
    const [curso] = await pool.promise().query('SELECT * FROM cursos WHERE id = ?', [cursoId]);

    if (curso.length === 0) {
      return res.status(404).json({ message: 'Curso não encontrado' });
    }

    res.json(curso[0]); // Retorna o primeiro curso encontrado
  } catch (error) {
    console.error('Erro ao obter detalhes do curso:', error);
    res.status(500).json({ message: 'Erro ao obter detalhes do curso' });
  }
});




// Servir página inicial
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/curso.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'curso.html'));
});


// Exportar o pool para uso em outros módulos
module.exports = pool;

// Iniciar o servidor
app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});









