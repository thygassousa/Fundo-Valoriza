function loginUsuario() {
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    // Enviar a requisição para o servidor
    fetch('/api/usuarios/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, senha }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Login realizado com sucesso!') {
            // Redireciona para a página do usuário após login
            window.location.href = '/index.html';  // Ou para qualquer outra página
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Erro no login:', error);
        alert('Erro ao realizar login!');
    });
}
