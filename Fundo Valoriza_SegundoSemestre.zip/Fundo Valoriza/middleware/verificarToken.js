const jwt = require('jsonwebtoken');

const verificarToken = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];  // Extrai o token do cabeçalho

    if (!token) {
        return res.status(403).json({ message: 'Token não fornecido.' });
    }

    jwt.verify(token, 'secreta-chave', (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Token inválido.' });
        }

        // Adiciona o ID do usuário no request para uso nas rotas seguintes
        req.user = decoded;  // Supondo que o token tenha o campo 'id'
        next();
    });
};


module.exports = verificarToken;
