document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('cursosContainer');
  const params = new URLSearchParams(window.location.search);
  const categoria = params.get('categoria') || 'todos';

  // Verifica se o usuário está autenticado
  async function verificarAutenticacao() {
      try {
          const token = localStorage.getItem('token'); // Recupera o token do localStorage
          if (!token) throw new Error('Token não encontrado');

          const response = await fetch('http://localhost:3000/api/usuarios/verificar', {
              method: 'GET',
              headers: { Authorization: token }
          });

          if (!response.ok) throw new Error('Não autorizado');
      } catch (error) {
          alert('Você precisa estar logado para acessar esta página!');
          window.location.href = 'login.html'; // Redireciona para o login
      }
  }

  await verificarAutenticacao(); // Chama a verificação antes de carregar os cursos

  async function carregarCursosPorCategoria(categoria = 'todos') {
      container.innerHTML = '<p class="text-center">Carregando cursos...</p>';
      try {
          const response = await fetch(`http://localhost:3000/api/cursos/listar?categoria=${encodeURIComponent(categoria)}`);
          const cursos = await response.json();

          container.innerHTML = '';

          if (cursos.length === 0) {
              container.innerHTML = '<p class="text-center">Nenhum curso disponível no momento.</p>';
              return;
          }

          cursos.forEach(curso => {
              const cursoCard = document.createElement('div');
              cursoCard.classList.add('col-md-4', 'curso-card');
              cursoCard.innerHTML = `
                  <div class="card">
                      <div class="card-body">
                          <h5 class="card-title">${curso.title}</h5>
                        
                          <p class="text-muted">Categoria: ${curso.category}</p>
                          <a href="detalhe-curso.html?id=${curso.id}" class="btn btn-primary">Ver mais</a>
                      </div>
                  </div>
              `;
              container.appendChild(cursoCard);
          });

      } catch (error) {
          console.error('Erro ao carregar cursos:', error);
          container.innerHTML = '<p class="text-danger text-center">Erro ao carregar os cursos. Tente novamente mais tarde.</p>';
      }
  }

  carregarCursosPorCategoria(categoria);

  document.querySelectorAll('.dropdown-item').forEach(item => {
      item.addEventListener('click', (event) => {
          const categoriaSelecionada = event.target.textContent.trim();
          const categoriaFinal = categoriaSelecionada === 'Todos os Cursos' ? 'todos' : categoriaSelecionada;
          window.location.href = `cursos.html?categoria=${encodeURIComponent(categoriaFinal)}`;
      });
  });
});
