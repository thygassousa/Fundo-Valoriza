document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('token');

  if (token) {
      // Mostrar ícones de perfil e logout, ocultar login e cadastro
      document.getElementById('loginNavItem').classList.add('d-none');
      document.getElementById('cadastroNavItem').classList.add('d-none');
      document.getElementById('profileNavItem').classList.remove('d-none');
      document.getElementById('logoutNavItem').classList.remove('d-none');
  } else {
      // Mostrar login e cadastro, ocultar perfil e logout
      document.getElementById('loginNavItem').classList.remove('d-none');
      document.getElementById('cadastroNavItem').classList.remove('d-none');
      document.getElementById('profileNavItem').classList.add('d-none');
      document.getElementById('logoutNavItem').classList.add('d-none');
  }
});

// Função para fazer logout
function logout() {
  localStorage.removeItem('token');
  window.location.href = 'index.html'; // Redirecionar após logout
}
