async function cadastrarUsuario() {
    const nome = document.getElementById('nome').value.trim();
    const sobrenome = document.getElementById('sobrenome').value.trim();
    const email = document.getElementById('email').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const dataNascimento = document.getElementById('dataNascimento').value;
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmarSenha').value;

    // Verificar campos obrigatórios
    if (!nome || !sobrenome || !email || !senha) {
        alert("Preencha todos os campos obrigatórios!");
        return;
    }

    // Verificar se as senhas coincidem
    if (senha !== confirmarSenha) {
        alert("As senhas não coincidem!");
        return;
    }

    // Ativar o spinner e desativar o botão
    const btnCadastro = document.getElementById('btnCadastro');
    const spinnerCadastro = document.getElementById('spinnerCadastro');
    btnCadastro.disabled = true;
    spinnerCadastro.classList.remove('d-none');

    try {
        const response = await fetch('http://localhost:3000/api/usuarios/cadastro', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                nome,
                sobrenome,
                email,
                telefone,
                dataNascimento,
                senha,
            }),
        });

        const data = await response.json();

        // Desativar o spinner e reativar o botão
        btnCadastro.disabled = false;
        spinnerCadastro.classList.add('d-none');

        if (response.ok) {
            alert(data.message || 'Usuário cadastrado com sucesso!');
            window.location.href = 'login.html'; // Redireciona para a página de login
        } else {
            alert(data.message || 'Erro ao cadastrar usuário. Tente novamente.');
        }
    } catch (error) {
        console.error('Erro:', error);
        btnCadastro.disabled = false;
        spinnerCadastro.classList.add('d-none'); // Remover o spinner em caso de erro
        alert('Ocorreu um erro ao se conectar ao servidor.');
    }
}
