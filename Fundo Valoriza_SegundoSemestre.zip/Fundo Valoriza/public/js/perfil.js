async function carregarDadosPerfil() {
    const token = localStorage.getItem('token');

    if (!token) {
        alert('Usuário não está logado. Redirecionando para a página de login.');
        window.location.href = 'login.html';
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/api/usuarios/perfil', {
            method: 'GET',
            headers: {
                Authorization: token
            }
        });

        if (response.status === 200) {
            const data = await response.json();
            const usuario = data.usuario;
            const cursos = data.cursos; // Lista de cursos inscritos

            // Atualizar dados do usuário
            document.getElementById('userName').textContent = usuario.nome;
            document.getElementById('userEmail').textContent = usuario.email;
            document.getElementById('userPhone').textContent = usuario.telefone || 'Não informado';
            document.getElementById('userBirthDate').textContent = usuario.data_nascimento || 'Não informada';

            // Atualizar lista de cursos inscritos
            const cursosContainer = document.getElementById('userCourses');
            if (cursos && cursos.length > 0) {
                cursosContainer.innerHTML = cursos.map(curso => `
                    <div class="course-item">
                        <h3>${curso.titulo}</h3>
                     
                    </div>
                `).join('');
            } else {
                cursosContainer.innerHTML = '<p>Você ainda não está inscrito em nenhum curso.</p>';
            }
        } else {
            alert('Erro ao carregar o perfil. Faça login novamente.');
            window.location.href = 'login.html';
        }
    } catch (error) {
        console.error('Erro ao carregar os dados do perfil:', error);
        alert('Erro no servidor. Tente novamente mais tarde.');
    }
}

// Função para fazer logout
function fazerLogout() {
  localStorage.removeItem('token');
  window.location.href = 'login.html';
}

// Carregar os dados do perfil ao carregar a página
document.addEventListener('DOMContentLoaded', carregarDadosPerfil);
