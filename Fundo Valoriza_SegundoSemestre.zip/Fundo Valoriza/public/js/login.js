async function fazerLogin() {
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const spinner = document.getElementById('spinnerLogin');

    spinner.classList.remove('d-none');

    try {
        const resposta = await fetch('http://localhost:3000/api/usuarios/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha })
        });

        spinner.classList.add('d-none');

        const data = await resposta.json();

        if (resposta.status === 200) {
            localStorage.setItem('token', data.token);
            window.location.href = 'index.html';  // Redirecionar para index.html
        } else {
            alert(data.message || 'Erro no login');
        }
    } catch (error) {
        console.error('Erro no login:', error);
        spinner.classList.add('d-none');
        alert('Erro ao realizar login.');
    }
}
