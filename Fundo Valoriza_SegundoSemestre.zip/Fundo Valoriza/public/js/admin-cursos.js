async function carregarCursos() {
    try {
        const response = await fetch('/api/admin/cursos');
        const cursos = await response.json();
        const tableBody = document.querySelector('#coursesTable tbody');

        // Limpa a tabela para evitar duplicação
        while (tableBody.firstChild) {
            tableBody.removeChild(tableBody.firstChild);
        }

        // Adiciona cada curso na tabela
        cursos.forEach(curso => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${curso.id}</td>
                <td>${curso.title}</td>
                <td>${curso.description}</td>
                <td>${curso.category}</td>
                <td>${curso.video_url ? `<a href="${curso.video_url}" target="_blank">Assistir</a>` : 'Sem vídeo'}</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editarCurso(${curso.id}, '${curso.title}', '${curso.description}', '${curso.category}', '${curso.video_url}')">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="excluirCurso(${curso.id})">Excluir</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Erro ao carregar cursos:', error);
    }
}

async function adicionarOuEditarCurso(event) {
    event.preventDefault();  // Evitar reload da página

    const submitButton = document.querySelector('#submitButton'); // O botão de envio do formulário
    submitButton.disabled = true; // Desativa o botão para evitar múltiplos cliques

    const id = document.getElementById('courseId').value;
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const category = document.getElementById('category').value;
    const videoUrl = document.getElementById('video_url').value;

    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/admin/cursos/${id}` : '/api/admin/cursos';

    try {
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, description, category, video_url: videoUrl })
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const message = id ? 'Curso atualizado com sucesso!' : 'Curso adicionado com sucesso!';
        alert(message);

        document.getElementById('courseForm').reset();
        carregarCursos();

    } catch (error) {
        alert('Erro ao salvar curso: ' + error.message);
        console.error(error);
    } finally {
        submitButton.disabled = false; // Reativa o botão após a tentativa de envio
    }
}



async function excluirCurso(id) {
    if (!confirm('Deseja realmente excluir este curso?')) return;

    try {
        const response = await fetch(`/api/admin/cursos/${id}`, { method: 'DELETE' });
        if (!response.ok) {
            throw new Error('Erro ao excluir curso');
        }

        alert('Curso excluído com sucesso!');
        carregarCursos();  // Atualiza a lista de cursos após exclusão

    } catch (error) {
        alert('Erro ao excluir curso: ' + error.message);
        console.error('Erro ao excluir curso:', error);
    }
}

function mostrarNotificacao(mensagem, tipo = 'success') {
    const notification = document.getElementById('notification');
    const notificationMessage = document.getElementById('notificationMessage');
    
    notificationMessage.textContent = mensagem;
    notification.className = `alert alert-${tipo}`;  // Tipo pode ser 'success' ou 'danger'
    notification.style.display = 'block';

    setTimeout(() => {
        notification.style.display = 'none';
    }, 5000);
}

// Exemplo de uso:
mostrarNotificacao('Curso adicionado com sucesso!', 'success');
mostrarNotificacao('Erro ao salvar curso.', 'danger');


function editarCurso(id, title, description, category, video_url) {
    document.getElementById('courseId').value = id;
    document.getElementById('title').value = title;
    document.getElementById('description').value = description;
    document.getElementById('category').value = category;
    document.getElementById('video_url').value = video_url;
}

// Adicionar o evento de submit para o formulário
document.getElementById('courseForm').addEventListener('submit', adicionarOuEditarCurso);

// Carregar cursos ao carregar a página
document.addEventListener('DOMContentLoaded', carregarCursos);